﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    /// <summary>
    /// class that stores information about the Tile
    /// </summary>
    public class Tile : GameObject
    {
        private AnimatedTexture past;
        private AnimatedTexture future;
        private bool pastCollidable;
        private bool futureCollidable;
        private bool isDoor;
       
        /// <summary>
        /// Gets whether the tile is collidable in the future
        /// </summary>
        public bool FutureCollidable
        {
            get
            {
                return futureCollidable;
            }
        }

        /// <summary>
        /// Gets whether the tile is collidable in the past
        /// </summary>
        public bool PastCollidable
        {
            get
            {
                return pastCollidable;
            }
        }

        public bool IsDoor
        {
            get
            {
                return isDoor;
            }
        }

        /// <summary>
        /// constructor for Tile
        /// </summary>
        /// <param name="past"> the AnimatedTexture for the past version of the Tile</param>
        /// <param name="future"> the AnimatedTexture for the future version of the TIle </param>
        /// <param name="pastCollidable"> whether or not the Tile is collidable in the past</param>
        /// <param name="futureCollidable"> whether or not the TIle is collidable in the future</param>
        /// <param name="door">if this tile is the door -- end of the level</param>
        /// 
        public Tile(Rectangle position, AnimatedTexture past, bool pastCollidable, AnimatedTexture future, bool futureCollidable, bool door, double scale)
            : base(position, pastCollidable, scale)
        {
            this.past = past;
            this.pastCollidable = pastCollidable;
            this.future = future;
            this.futureCollidable = futureCollidable;
            this.isDoor = door;
        }

        /// <summary>
        /// Really doesn't do anything don't call this
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Update(GameTime gameTime)
        {
            //implement code here
        }

        /// <summary>
        /// Calls the draw method of the animated texture based on the current timestate
        /// </summary>
        /// <param name="gameTime">Game1's gameTime</param>
        /// <param name="sb">The Official Spritebath(TM)</param>
        public override void Draw(GameTime gameTime, SpriteBatch sb)
        {
            if(Game1.timeState == TimeState.Past)
            {
                past.Draw(position, sb, gameTime, SpriteEffects.None);
            }
            else
            {
                future.Draw(position, sb, gameTime, SpriteEffects.None);
            }
        }
    }
}
