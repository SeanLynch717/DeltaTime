﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    public enum GameState{
        Start,
        PauseMenu,
        Level1,
        Level2,
        Level3,
        End
    }
    public enum TimeState
    {
        Past,
        Future
    }

    /// <summary>
    /// Yellow bird is better then the blue bird.
    /// Sky is a woman
    /// Justin is able to type basic sentences. (and little else)
    /// Jimmie Harkins
    /// </summary>
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private Dictionary<PlayerState, Texture2D> playerSpriteSheets;
        private Dictionary<ChickenState, Texture2D> chickenSpriteSheets;
        private Dictionary<TreeState, Texture2D> treeSpriteSheets;
        private Dictionary<String, Texture2D> tileTextures;
        private UIManager uiManager;
        private CollisionManager collisionManager;
        private InputManager inputManager;
        private LevelManager levelManager;
        private Player player;
        private double playerScale;
        private AnimationManager animationManager;
        private Texture2D pickupIndicatorTexture;
        public static TimeState timeState;
        public static GameState gameState;

        public static StaticTextureManager staticTextureManager;

        //Debug objects
        private UIText timeText;
        private SpriteFont arial16;
        private Chicken debugChicken;
        private Tree debugTree;
        //End debug objects

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            IsMouseVisible = true;

            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.ApplyChanges();

            gameState = GameState.Start;
            timeState = TimeState.Future;

            //Debug
            uiManager = new UIManager();
            arial16 = Content.Load<SpriteFont>("Arial16");
            timeText = new UIText(arial16, "future", new Vector2(10,10));
            uiManager.Add(timeText);

            debugChicken = new Chicken(new Rectangle(64, 64, 64, 64), ChickenState.Bones, 1);
            debugTree = new Tree(new Rectangle(128, 64, 64, 64), TreeState.Sapling , 1);
            //End Debug

            playerScale = 1.5;
            player = new Player(new Rectangle(100, 300, 38,40), true, playerScale);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            playerSpriteSheets = new Dictionary<PlayerState, Texture2D>();
            playerSpriteSheets[PlayerState.FacingLeft] = Content.Load<Texture2D>("sonicStandingSpriteSheet"); //all temporary code
            playerSpriteSheets[PlayerState.WalkingLeft] = Content.Load<Texture2D>("sonicWalkingSpriteSheet");
            player[PlayerState.WalkingLeft] = new AnimatedTexture(10, 38, 40, playerSpriteSheets[PlayerState.WalkingLeft]);
            player[PlayerState.WalkingRight] = new AnimatedTexture(10, 38, 40, playerSpriteSheets[PlayerState.WalkingLeft]);
            player[PlayerState.WalkingDown] = new AnimatedTexture(0, 38, 40, playerSpriteSheets[PlayerState.FacingLeft]);
            player[PlayerState.WalkingUp] = new AnimatedTexture(0, 38, 40, playerSpriteSheets[PlayerState.FacingLeft]);
            player[PlayerState.FacingDown] = new AnimatedTexture(0, 38, 40, playerSpriteSheets[PlayerState.FacingLeft]);
            player[PlayerState.FacingLeft] = new AnimatedTexture(0, 38, 40, playerSpriteSheets[PlayerState.FacingLeft]);
            player[PlayerState.FacingRight] = new AnimatedTexture(0, 38, 40, playerSpriteSheets[PlayerState.FacingLeft]);
            player[PlayerState.FacingUp] = new AnimatedTexture(0, 38, 40, playerSpriteSheets[PlayerState.FacingLeft]);
            pickupIndicatorTexture = Content.Load<Texture2D>("pickupIndicator");
            player.IndicatorTexture = pickupIndicatorTexture;
            chickenSpriteSheets = new Dictionary<ChickenState, Texture2D>();
            foreach(ChickenState state in Enum.GetValues(typeof(ChickenState)))
            {
                chickenSpriteSheets[state] = Content.Load<Texture2D>("Chicken_" + state.ToString());
            }
            debugChicken.LoadTextures(chickenSpriteSheets);

            //Tree sprite loading - uncomment when we have sprites for them
            /*
            treeSpriteSheets = new Dictionary<TreeState, Texture2D>();
            foreach(TreeState state in Enum.GetValues(typeof(TreeState)))
            {
                treeSpriteSheets[state] = Content.Load<Texture2D>("Tree_" + state.ToString());
            }
            debugTree.LoadTextures(treeSpriteSheets);
            */

            //temporay buttons
            UIButton start = new UIButton(Content.Load<Texture2D>("startGame_up"),Content.Load<Texture2D>("startGame_ovr"),Content.Load<Texture2D>("startGame_ovr"), new Rectangle(GraphicsDevice.Viewport.Width/2-80, GraphicsDevice.Viewport.Height/4, 160, 80));
            UIButton pause = new UIButton(Content.Load<Texture2D>("Pause"), Content.Load<Texture2D>("Pause"),Content.Load<Texture2D>("Pause"), new Rectangle(GraphicsDevice.Viewport.Width-32,0, 32,32));
            UIButton resume = new UIButton(Content.Load<Texture2D>("Resume"), Content.Load<Texture2D>("Resume"), Content.Load<Texture2D>("Resume"),new Rectangle(GraphicsDevice.Viewport.Width/2 - 64, GraphicsDevice.Viewport.Height/4, 128,64));
            uiManager.Add("start",start);
            uiManager.Add("pause", pause);
            uiManager.Add("resume", resume);



            tileTextures = new Dictionary<string, Texture2D>();
            tileTextures.Add("floor", Content.Load<Texture2D>("FloorPH"));
            tileTextures.Add("block", Content.Load<Texture2D>("BlockPH"));
            tileTextures.Add("door", Content.Load<Texture2D>("DoorPH"));

            staticTextureManager = new StaticTextureManager();
            staticTextureManager["indicator"] = Content.Load<Texture2D>("Indicator");

            levelManager = new LevelManager(tileTextures);
            collisionManager = new CollisionManager(player, levelManager);
            animationManager = new AnimationManager(levelManager, player, uiManager, new AnimatedTexture(4, 32, 32, Content.Load<Texture2D>("timeTravelEffect")), collisionManager);
            inputManager = new InputManager(player, levelManager, uiManager, collisionManager, animationManager);

            levelManager.ThisLevel.AddInteractable(debugChicken);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            //Always update input.
            inputManager.Update();
            //Finite State Machine for updating the GameState specifics
            switch (gameState)
            {
                case GameState.Start:
                    {
                        break;
                    }
                case GameState.PauseMenu:
                    {
                        break;
                    }
                case GameState.End:
                    {
                        break;
                    }
                default:
                    {
                        //Only update collision manager when the player is in a level.
                        collisionManager.Update();
                        if (Game1.timeState == TimeState.Past)
                        {
                            timeText.Text = "past";
                        }
                        else
                        {
                            timeText.Text = "future";
                        }

                        levelManager.ThisLevel.Update(gameTime);
                        break;
                    }
            }         
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin(SpriteSortMode.Deferred, null, SamplerState.PointClamp, null, null, null, null);

            //Only need to call Draw on the AnimationManager.
            animationManager.Draw(spriteBatch, gameTime);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
