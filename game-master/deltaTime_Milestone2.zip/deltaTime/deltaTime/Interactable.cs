﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    /// <summary>
    /// A <c>GameObject</c> that has different states that can change with time or player interaction
    /// </summary>
    public abstract class Interactable : GameObject
    {
        /// <summary>
        /// Gets the coordinates of the interactable relative to the grid
        /// </summary>
        public Vector2 GridCoords {
            get
            {
                return new Vector2(position.X / 64, position.Y / 64);
            }
        }
        /// <summary>
        /// Constructor for Interactable
        /// </summary>
        /// <param name="position">The position the Interactable starts at</param>
        /// <param name="Collidable">Whether or not the Interactable is collidable</param>
        public Interactable(Rectangle position, bool collidable, double scale):base(position, collidable, scale)
        {
            //implement code here
        }

        /// <summary>
        /// Performs whatever actions happen when the interactable goes to the past
        /// To be implemented in child classes
        /// </summary>
        public abstract void GoToPast();

        /// <summary>
        /// Performs whatever actions happen when the interactable goes to the future
        /// To be implemented in child classes
        /// </summary>
        public abstract void GoToFuture();

        /// <summary>
        /// Converts a dictionary mapping states to spritesheets to a dictionary mapping states to AnimatedTextures.
        /// </summary>
        /// <param name="spriteSheets">The spriteSheets to take in</param>
        /// <typeparam name="State">The enum for the states of the interactable you are loading sprites in for</typeparam>
        /// <returns>A dictionary of animated textures to be used by the child interactable</returns>
        protected Dictionary<State, AnimatedTexture> ConvertTextures<State>(Dictionary<State, Texture2D> spriteSheets, int fps, int widthOfFrame, int heightOfFrame)
        {
            Dictionary<State, AnimatedTexture> returnDict = new Dictionary<State, AnimatedTexture>();

            foreach (State state in spriteSheets.Keys)
            {
                returnDict[state] = new AnimatedTexture(fps, widthOfFrame, heightOfFrame, spriteSheets[state]);
            }

            return returnDict;
        }

        public abstract void LoadTextures(IDictionary spriteSheets);
    }
}
