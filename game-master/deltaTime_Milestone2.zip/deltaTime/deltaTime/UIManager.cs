﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    /// <summary>
    /// 
    /// </summary>
    class UIManager
    {
        private Dictionary<string,UIButton> buttons;
        private List<UIText> texts;

        /// <summary>
        /// constructor for UIManager
        /// </summary>
        /// <param name="buttons"></param>
        public UIManager()
        {
            buttons = new Dictionary<string, UIButton>();
            texts = new List<UIText>();
        }
        /// <summary>
        /// Getter for buttons
        /// </summary>
        /// <param name="index"> the index to get</param>
        /// <returns> the button at index</returns>
        public UIButton this[string index]
        {
            get { return buttons[index]; }
        }
        public void Draw(GameState gameState, GameTime gameTime, SpriteBatch sb)
        {
            //Draw title screen along with necessary buttons when in the menu.
            if(gameState == GameState.Start)
            {
                buttons["start"].Draw(gameTime, sb);
            }
            //Draw the pause menu.
            else if(gameState == GameState.PauseMenu)
            {   
                buttons["resume"].Draw(gameTime, sb);
            }
            //Draw necessary level UI.
            else if(gameState == GameState.End)
            {

            } 
            //Draw end game components.
            else
            {
                foreach (UIText text in texts)
                {
                    buttons["pause"].Draw(gameTime, sb);
                    text.Draw(gameTime, sb);
                }
            }
        }

        /// <summary>
        /// Adds a button to the UI Manager
        /// </summary>
        /// <param name="b">The button to add</param>
        public void Add(string key, UIButton value)
        {
            buttons[key] = value;
        }

        /// <summary>
        /// Adds a text to the UI Manager
        /// </summary>
        /// <param name="b">The text to add</param>
        public void Add(UIText t)
        {
            texts.Add(t);
        }
    }
}
