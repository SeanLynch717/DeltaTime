﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    /// <summary>
    /// this class deals with all of the collisions within the game
    /// </summary>
    class CollisionManager
    {
        private Player player;
        private LevelManager levelManager;
        private Tile[,] levelArray;

        //This method 
        public CollisionManager(Player p, LevelManager lm)
        {
            player = p;
            levelManager = lm;
            levelArray = levelManager.ThisLevel.Tiles;
            //implement code here
        }
        //detects collisions between the player and the objects in the level.
        public void Update()
        {
            //implement code here

            //If player is inside a wall, move him out in the right direction. 
            //Make a new rect, make its x the players x and its y the players y + 32
            //If tile bool is past collidable, do diffrent things
            foreach (Tile tile in levelArray)
            {
                //Point playerSpot = new Point(player.Position.X / 64, player.Position.Y / 64);
                //Checking to see if the tiles are collidable in the future or past
                if (Game1.timeState == TimeState.Future && tile.FutureCollidable == false)
                {
                    continue;
                }
                if (Game1.timeState == TimeState.Past && tile.PastCollidable == false)
                {
                    continue;
                }

                //---------------------------------------------------------------------------------------------------------------------------
                Rectangle intersectingRect = Rectangle.Intersect(player.Position, tile.Position);

                if (intersectingRect != Rectangle.Empty)
                {
                    if(tile.IsDoor)
                    {
                        levelManager.CurrentLevel++;

                        //returns player to beginning when you complete all levels
                        if (levelManager.CurrentLevel == levelManager.MaxLevel)
                            levelManager.CurrentLevel = 0;
                            

                        player.X = 100;
                        player.Y = 300;
                        levelArray = levelManager.ThisLevel.Tiles;
                        return;
                    }

                    if (intersectingRect.Width > intersectingRect.Height)
                    {
                        //Move player up or down
                        if (tile.Y < player.Y)
                        {
                            //above, move player down
                            player.Y += player.Speed;
                        }
                        else
                        {
                            //below, move player up
                            player.Y -= player.Speed;

                        }
                    }
                    else
                    {
                        //Move player left or right
                        if (tile.X < player.X)
                        {
                            //Left, move player right
                            player.X += player.Speed;
                        }
                        else
                        {
                            //right, move player left
                            player.X -= player.Speed;

                        }
                    }

                }
            }
        }
        /// <summary>
        /// Checks whether or not the player will collide with a wall in the other time state.
        /// </summary>
        /// <returns><c>true</c> if the player will collide with a wall in the non-present time state, <c>false</c> otherwise</returns>
        public bool PlayerIsCollidingInOtherTime()
        {
            int centerY = player.Y / 64;
            int centerX = player.X / 64;
            for(int row = centerY - 1; row <= centerY + 1; row++)
            {
                for(int col = centerX - 1; col <= centerX + 1; col++)
                {
                    if (row >= 0 && col >= 0)
                    {                      
                        if(Game1.timeState == TimeState.Past && levelArray[row, col].FutureCollidable && player.Position.Intersects(levelArray[row, col].Position))
                        {
                            return true;
                        }
                        else if (Game1.timeState == TimeState.Future && levelArray[row, col].PastCollidable && player.Position.Intersects(levelArray[row, col].Position))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }
}
