﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    public enum TreeState { PastNothing, Sapling, Tree, DeadTree, FutureNothing}
    class Tree : Interactable
    {

        private TreeState state;
        private Dictionary<TreeState, AnimatedTexture> textures;

        /// <summary>
        /// Gets the state of the tree
        /// </summary>
        public TreeState State
        {
            get
            {
                return state;
            }
        }

        public AnimatedTexture this[TreeState s]
        {
            get
            {
                return textures[s];
            }
        }

        public Tree(Rectangle position, TreeState state, double scale) : base(position, true, scale)
        {
            this.state = state;
        }

        public override void Update(GameTime gameTime)
        {
            //implement code here
        }

        public override void Draw(GameTime gameTime, SpriteBatch sb)
        {
            textures[state].Draw(Position, sb, gameTime, SpriteEffects.None);
        }

        /// <summary>
        /// changes the current state of the tree to its previous state as long as it isn't in its base state
        /// </summary>
        public override void GoToPast()
        {
            switch (state)
            {
                case TreeState.PastNothing:
                    //this should never happen
                    break;
                case TreeState.Sapling:
                    state = TreeState.PastNothing;
                    break;
                case TreeState.Tree:
                    state = TreeState.Sapling;
                    break;
                case TreeState.DeadTree:
                    state = TreeState.Tree;
                    break;
                case TreeState.FutureNothing:
                    state = TreeState.DeadTree;
                    break;
            }
        }

        /// <summary>
        /// changes the current state of the tree to its next state as long as it isn't in its oldest state.
        /// </summary>
        public override void GoToFuture()
        {
            switch (state)
            {
                case TreeState.PastNothing:
                    state = TreeState.Sapling;
                    break;
                case TreeState.Sapling:
                    state = TreeState.Tree;
                    break;
                case TreeState.Tree:
                    state = TreeState.DeadTree;
                    break;
                case TreeState.DeadTree:
                    state = TreeState.FutureNothing;
                    break;
                case TreeState.FutureNothing:
                    //this should never happen
                    break;
            }
        }

        /// <summary>
        /// Loads a dictionary mapping ChickenStates to SpriteSheets, 
        /// converts it to a dictionary mapping ChickenStates to 
        /// AnimatedTextures, then sets this Chicken's texture field
        /// to that dictionary
        /// </summary>
        /// <param name="spriteSheets">The dictionary</param>
        /// <param name="fps">The fps of the animatedTextures</param>
        /// <param name="widthOfFrame">The width of frame of the animatedTextures</param>
        /// <param name="heightOfFrame">The height of frame of the animatedTextures</param>
        public override void LoadTextures(IDictionary spriteSheets)
        {
            //converts to chicken-specific spritesheets
            Dictionary<TreeState, Texture2D> castedSpriteSheets = (Dictionary<TreeState, Texture2D>)spriteSheets;

            //converts to animatedTextures
            //int values of fps, width, and height can be changed here and should probably be kept as variables somewhere
            Dictionary<TreeState, AnimatedTexture> animatedTextures = ConvertTextures(castedSpriteSheets, 30, 32, 32);

            textures = animatedTextures;
        }
    }
}
