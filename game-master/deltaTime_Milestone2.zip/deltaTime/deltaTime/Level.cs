﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;

namespace deltaTime
{
    /// <summary>
    /// A level, holding a two-dimensional array of tiles and a list of interactables in the level
    /// </summary>
    public class Level
    {
        private Tile[,] tiles;
        private List<Interactable> interactables;
        private List<Indicator> indicators;
        //private bool isFuture;

        /// <summary>
        /// Creates a level given a file name and a dictionary of tile textures to use
        /// </summary>
        public Level(String fileName, Dictionary<String, Texture2D> tileTextures)
        {
            interactables = new List<Interactable>();
            indicators = new List<Indicator>();
            tiles = new Tile[12, 16];
            //finds file, creates holder string for reader
            StreamReader reader = new StreamReader(fileName);
            String line = "";
            String[] words;

            //for every tile in the 2D array:\
            //checks if this tile is a floor tile is past and/or future
            //if floor, make it non-collidable in that timeState
            //otherwise, it is collidable
            for (int h = 0; h < 12; h++)
            {
                for (int w = 0; w < 16; w++)
                {
                    line = reader.ReadLine();
                    //ignore documented lines in Level files
                    if (line[0] != '/')
                    {
                        words = line.Split(' ');

                        //handles situations where both, one, or neither time state is collidable
                        if(words[0] == "door")
                        {
                            tiles[h, w] = new Tile(
                               new Rectangle((w * 64), (h * 64), 64, 64),
                               new AnimatedTexture(0, 32, 32, tileTextures[words[0]]), true,
                               new AnimatedTexture(0, 32, 32, tileTextures[words[2]]), true,
                               true, 1);
                        }
                        else if (words[0] == "floor" && words[2] == "floor")
                        {
                            tiles[h, w] = new Tile(
                                new Rectangle((w * 64), (h * 64), 64, 64),
                                new AnimatedTexture(0, 32, 32, tileTextures[words[0]]), false,
                                new AnimatedTexture(0, 32, 32, tileTextures[words[2]]), false,
                                false, 1);
                        }
                        else if (words[0] == "floor" && words[2] != "floor")
                        {
                            tiles[h, w] = new Tile(
                                new Rectangle((w * 64), (h * 64), 64, 64),
                                new AnimatedTexture(0, 32, 32, tileTextures[words[0]]), false,
                                new AnimatedTexture(0, 32, 32, tileTextures[words[2]]), true,
                                false , 1);
                        }
                        else if (words[0] != "floor" && words[2] == "floor")
                        {
                            tiles[h, w] = new Tile(
                                new Rectangle((w * 64), (h * 64), 64, 64),
                                new AnimatedTexture(0, 32, 32, tileTextures[words[0]]), true,
                                new AnimatedTexture(0, 32, 32, tileTextures[words[2]]), false,
                                false , 1);
                        }
                        else if (words[0] != "floor" && words[2] != "floor")
                        {
                            tiles[h, w] = new Tile(
                                new Rectangle((w * 64), (h * 64), 64, 64),
                                new AnimatedTexture(0, 32, 32, tileTextures[words[0]]), true,
                                new AnimatedTexture(0, 32, 32, tileTextures[words[2]]), true,
                                false , 1);
                        }
                    }
                    //this part of if ladder just makes sure that skipping lines due to documentation in the level files
                    //doesn't skip a tile
                    else if (w == 0)
                    {
                        w = 15;
                        h--;
                    }
                    else
                        w--;
                }
            }
        }

        //way to access 2D array within level
        //I think this is also only used bt CollisionManager
        public Tile[,] Tiles
        {
            get
            {
                return tiles;
            }
        }

        public List<Interactable> Interactables
        {

            get
            {
                return interactables;
            }

        }

        public List<Indicator> Indicators
        {
            get
            {
                return indicators;
            }
        }

        public void Update(GameTime gameTime)
        {
            for (int i = 0; i < indicators.Count; i++)
            {
                indicators[i].Update(gameTime);
                if(indicators[i].LifetimeLeft < 0)
                {
                    indicators.Remove(indicators[i]);
                    i--;
                }
            }

        }
        /// <summary>
        /// Draws all tiles and interactables in the level
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="sb">The spritebatch to draw with</param>
        public void Draw(GameTime gameTime, SpriteBatch sb)
        {
            for (int h = 0; h < 12; h++)
            {
                for (int w = 0; w < 16; w++)
                {
                    tiles[h, w].Draw(gameTime, sb);
                }
            }
            foreach(Interactable i in interactables)
            {
                i.Draw(gameTime, sb);
            }
            foreach(Indicator i  in indicators)
            {
                i.Draw(gameTime, sb);
            }
        }

        /// <summary>
        /// Adds an interactable to the level
        /// </summary>
        /// <param name="i">The interactable to add</param>
        public void AddInteractable(Interactable i)
        {
            interactables.Add(i);
        }
        /// <summary>
        /// Removes an interactable from the level
        /// </summary>
        /// <param name="i">The interactable to remove</param>
        public void RemoveInteractable(Interactable i)
        {
            interactables.Remove(i);
        }

        /// <summary>
        /// Brings the level and all interactables in it to the past
        /// </summary>
        public void GoToPast()
        {
            foreach(Interactable i in interactables)
            {
                i.GoToPast();
            }
        }

        /// <summary>
        /// Brings the level and all interactables in it to the future
        /// </summary>
        public void GoToFuture()
        {
            foreach (Interactable i in interactables)
            {
                i.GoToFuture();
            }
        }

        /// <summary>
        /// Checks whether the given point (in grid space) is empty
        /// </summary>
        /// <param name="x">The X position to check (in grid space)</param>
        /// <param name="y">The Y position to check (in grid space)</param>
        /// <returns><c>true</c> if the position has no collidable tile or interactable in it, <c>false</c> otherwise</returns>
        public bool IsEmpty(int x, int y, TimeState timeState)
        {
            bool empty = true;
            //I'm going to guess that we dont want the player to be able to place the interactables somewhere that will be a wall in the next time state.
            if (timeState == TimeState.Past)
            {
                if (tiles[y,x].PastCollidable)
                {
                    empty = false;
                }
            }
            else
            {
                if (tiles[y,x].FutureCollidable)
                {
                    empty = false;
                }
            }
            /*
            foreach(Interactable i in interactables)
            {
                if(i.GridCoords == new Vector2(x,y))
                {
                    empty = false;
                }
            }
            */

            return empty;
        }

        public List<Interactable> InteractablesCollidingInOtherTime()
        {
            List<Interactable> collidingInteractables = new List<Interactable>();
            foreach(Interactable i in interactables)
            {
                if (!IsEmpty((int)i.GridCoords.X, (int)i.GridCoords.Y, //if there is a tile there
                    Game1.timeState == TimeState.Past ? TimeState.Future : TimeState.Past))
                {
                    collidingInteractables.Add(i);
                }
            }
            return collidingInteractables;
        }
        /// <summary>
        /// Gets the interactable at given position x,y in grid space
        /// </summary>
        /// <param name="x">The x position to get the interactable at</param>
        /// <param name="y">The y position to get the interactable at</param>
        /// <returns>The interactable at that position, if it exists, otherwise <c>null</c></returns>
        public Interactable InteractableAt(int x, int y)
        {
            foreach(Interactable i in interactables)
            {
                if (i.GridCoords == new Vector2(x, y))
                {
                    return i;
                }
            }
            return null;
        }

        public Interactable InteractableAt(Vector2 v)
        {
            return InteractableAt((int)v.X, (int)v.Y);
        }
    }
}
