﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    class AnimationManager
    {
        private LevelManager levelManager;
        private Player player;
        private UIManager uiManager;
        private CollisionManager colManager;
        private AnimatedTexture timeTravelAnim;
        private double length;
        private double dSpiralAngle;
        private double dShearAngle;
        private double dXOffSet;
        
        private Rectangle playerPosBeforeTimeTravel;
        private Dictionary<Interactable, Rectangle> interactablesPosBeforeTimeTravel;

        /// <summary>
        /// Contructs an AnimationManager object.
        /// </summary>
        /// <param name="lm"> The LevelManager.</param>
        /// <param name="p"> The Player.</param>
        /// <param name="uiManager"> The UIManager.</param>
        /// <param name="inputManager"> The InputManager</param>
        /// <param name="timeTravelAnim"> The time travel animation. </param>
        /// <param name="colManager"> The CollisionManager.</param>
        public AnimationManager(LevelManager lm, Player p, UIManager uiManager, AnimatedTexture timeTravelAnim, CollisionManager colManager)
        {
            this.levelManager = lm;
            this.player = p;
            this.uiManager = uiManager;
            this.timeTravelAnim = timeTravelAnim;
            this.colManager = colManager;
            interactablesPosBeforeTimeTravel = new Dictionary<Interactable, Rectangle>();
            dSpiralAngle = 1;
            dShearAngle = Math.PI/2;
            length = 100;
            dXOffSet = 2;
        }
        /// <summary>
        /// Draws all of the animations of the current State of the Game.
        /// </summary>
        /// <param name="spriteBatch"> The SpriteBatch</param>
        /// <param name="gameTime"> The GameTime</param>
        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            //Finite State Machine for drawing the game based on the current GameState.
            switch (Game1.gameState)
            {
                case GameState.Start:
                    {

                        break;
                    }
                case GameState.PauseMenu:
                    {

                        break;
                    }
                case GameState.End:
                    {
                        break;
                    }
                //Level
                default:
                    {
                        //While in a level, always draw all the tiles, interactable, and the player.
                        levelManager.DrawLevel(gameTime, spriteBatch);
                        player.Draw(gameTime, spriteBatch);

                        //Condition for time travel.
                        if(player.InTimeTravelAnim)
                        {
                            ShearScreen(); //Needs to be called first because DrawSpiralAnim corrects the offset that the shear has created.

                            DrawSpiralAnim(gameTime, spriteBatch); //Needs to be called last because when the animation is done, the screen gets corrected.
                        }
                        break;
                    }
            }
            //Always draws the uiManagers
            uiManager.Draw(Game1.gameState, gameTime, spriteBatch);
        }

        public void StartTimeTravel()
        {
            playerPosBeforeTimeTravel = player.Position;
            foreach (Interactable i in levelManager[levelManager.CurrentLevel].Interactables)
            {
                interactablesPosBeforeTimeTravel[i] = i.Position;
            }

            if (player.PlayerState == PlayerState.WalkingLeft)
            {
                player.PlayerState = PlayerState.FacingLeft;
            }
            else if (player.PlayerState == PlayerState.WalkingRight)
            {
                player.PlayerState = PlayerState.FacingRight;
            }
            else if (player.PlayerState == PlayerState.WalkingUp)
            {
                player.PlayerState = PlayerState.FacingUp;
            }
            else if (player.PlayerState == PlayerState.WalkingDown)
            {
                player.PlayerState = PlayerState.FacingDown;
            }

            player.InTimeTravelAnim = true;
        }
        /// <summary>
        /// Draws the spiral animation around the player, and re-center the screen once the animation is done incase the screen was
        /// sheared in the process.
        /// </summary>
        /// <param name="gameTime"> The GameTime </param>
        /// <param name="spriteBatch"> The SpriteBatch</param>
        public void DrawSpiralAnim(GameTime gameTime, SpriteBatch spriteBatch)
        {
            //Once the time travel animation is started
            if (player.InTimeTravelAnim == false)
            {
                player.InTimeTravelAnim = true;
            }

            //Draw each of the sprites. Offsetting the angle each time
            for (double angle = 0; angle < 2 * Math.PI; angle += Math.PI / 8)
            {
                timeTravelAnim.Draw(new Rectangle((int)(player.X + Math.Cos(angle + dSpiralAngle) * length) + (player.Position.Width/2), (int)(player.Y + Math.Sin(angle + dSpiralAngle) * length) 
                    + (player.Position.Height/2), 32, 32), spriteBatch, gameTime, SpriteEffects.None);
            }

            //Decrease the length at an increasing rate. Can tweak numbers to get desired output.
            length -= .2 + (dSpiralAngle);
            //Change the angle at an increasing rate. Can tweak numbers to get desired output.
            dSpiralAngle += .01 * (1 + 4 * dSpiralAngle);

            //Once the sprites have converged onto one another, end the animation and initiate time travel.
            if (length <= 0)
            {
                player.InTimeTravelAnim = false;
                length = 100;
                dSpiralAngle = 1;
                dXOffSet = 2;
                CenterScreen(); //Center the screen.
                levelManager.TimeStateChange(); //Switch time state.          
            }
        }
        /// <summary>
        /// Shears the screen so that each row of tiles and interactable move in unison according to the sin wave, with each row phased off from one another.
        /// </summary>
        public void ShearScreen()
        {
            Rectangle currentTile;
            int rowLength = levelManager[levelManager.CurrentLevel].Tiles.GetLength(0);
            int colLength = levelManager[levelManager.CurrentLevel].Tiles.GetLength(1);
            //Loop through every tile and shift all tiles in the same row in unison according to the sin curve.
            for(int row = 0; row < rowLength; row++)
            {
                for(int col = 0; col < colLength; col++)
                {
                    //Move the tile with respect to it's row and the sin curve
                    currentTile = levelManager[levelManager.CurrentLevel].Tiles[row,col].Position;
                    currentTile  = new Rectangle(currentTile.X +(int)(dXOffSet*(Math.Sin(dShearAngle + row*(2*Math.PI/rowLength)))), currentTile.Y, currentTile.Width, currentTile.Height);
                    levelManager[levelManager.CurrentLevel].Tiles[row,col].Position = currentTile;
                }
            }    
            //Loop through every Interactable and shift all tiles in the same row in unison according to the sin curve.
            foreach(GameObject g in levelManager[levelManager.CurrentLevel].Interactables)
            {
                //Move the interactable with respect to it's row and the sin curve
                g.Position = new Rectangle(g.X +(int)(dXOffSet*(Math.Sin(dShearAngle + (g.Y/64)*(2*Math.PI/rowLength)))), g.Y, g.Position.Width, g.Position.Height);
            }
            player.Position = new Rectangle(player.X +(int)(dXOffSet*(Math.Sin(dShearAngle + player.Y/64*(2*Math.PI/rowLength)))), player.Y, player.Position.Width, player.Position.Height);
            dShearAngle += .5;
            dXOffSet += .5;
            if(dShearAngle > 2 * Math.PI)
            {
                dShearAngle = 0;
            }               
        }
        /// <summary>
        /// Centers the screen. The purpose of this method is to compensate for the offset that ShearScreen created.
        /// </summary>
        public void CenterScreen() // We can get rid of this method if ShearScreen uses perlin noise loops instead of the sin wave.                              
        {                          // This is beacause the start and end positions would be the same (i.e. no offset).
            Rectangle currentTile;
            int rowLength = levelManager[levelManager.CurrentLevel].Tiles.GetLength(0);
            int colLength = levelManager[levelManager.CurrentLevel].Tiles.GetLength(1);
            //Go through each tile in the level and reset their positions.
            for(int row = 0; row < rowLength; row++)
            {
                for(int col = 0; col<colLength; col++)
                {
                    currentTile = levelManager[levelManager.CurrentLevel].Tiles[row,col].Position;
                    currentTile = new Rectangle(col * 64, row * 64, currentTile.Width, currentTile.Height);
                    levelManager[levelManager.CurrentLevel].Tiles[row,col].Position = currentTile;
                } 
                //reset the player's position
                player.Position = playerPosBeforeTimeTravel;
                //Go through each Interactable in the level and reset their positions.
                
                foreach(Interactable i in levelManager[levelManager.CurrentLevel].Interactables)
                {
                    i.Position = interactablesPosBeforeTimeTravel[i];
                }
                
            }
        }
    }
}
