﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    /// <summary>
    /// this class deals with all of the input from the user.
    /// </summary>
    class InputManager
    {
        private KeyboardState kbState;
        private KeyboardState previousKbState;
        private Player player;
        private LevelManager levelManager;
        private UIManager uiManager;
        private CollisionManager colManager;
        private AnimationManager animManager;


        /// <summary>
        /// constructor for InputManager
        /// </summary>
        public InputManager(Player p, LevelManager lm, UIManager ui, CollisionManager col, AnimationManager anim)
        {
            player = p;
            levelManager = lm;
            uiManager = ui;
            colManager = col;
            animManager = anim;
        }
        /// <summary>
        /// updates the game based on the users input
        /// </summary>
        public void Update()
        {
            previousKbState = kbState;
            kbState = Keyboard.GetState();

            //Always check for player using UI Elements.
            ProcessUIElements();
            //Only check for player input if the user is in a level.
            if (Game1.gameState.ToString().Substring(0, 5) == "Level")
            {
                //Player is not time traveling.
                if (!player.InTimeTravelAnim)
                { 
                    ProcessPlayerState();
                    ProcessMovement();
                    ProcessPickup();
                    ProcessTimeTravel();
                }
            }
        }
        /// <summary>
        /// Checks if this is the first frame the key is being pressed
        /// </summary>
        /// <param name="key">The key to check</param>
        /// <returns>True if this is the first frame the key is being pressed, false otherwise</returns>
        public bool KeyPress(Keys key)
        {
            if(kbState.IsKeyDown(key) && previousKbState.IsKeyUp(key))
            {
                return true;
            } else
            {
                return false;
            }

        }
        public void ProcessPlayerState()
        {
            //Updates the players finite state machine.
            switch(player.PlayerState){
                case PlayerState.FacingDown:{
                    if (kbState.IsKeyDown(Keys.S))
                    {
                        player.PlayerState = PlayerState.WalkingDown;
                    }
                    if (kbState.IsKeyDown(Keys.D))
                    {
                        player.PlayerState = PlayerState.FacingRight;
                    }
                    if (kbState.IsKeyDown(Keys.W))
                    {
                        player.PlayerState = PlayerState.FacingUp;
                    }
                    if (kbState.IsKeyDown(Keys.A))
                    {
                        player.PlayerState = PlayerState.FacingLeft;
                    }
                    break;
                }
                case PlayerState.FacingLeft:{
                    if (kbState.IsKeyDown(Keys.S))
                    {
                        player.PlayerState = PlayerState.FacingDown;
                    }
                    if (kbState.IsKeyDown(Keys.D))
                    {
                        player.PlayerState = PlayerState.FacingRight;
                    }
                    if (kbState.IsKeyDown(Keys.W))
                    {
                        player.PlayerState = PlayerState.FacingUp;
                    }
                    if (kbState.IsKeyDown(Keys.A))
                    {
                        player.PlayerState = PlayerState.WalkingLeft;
                    }
                    break;
                }
                case PlayerState.FacingRight:{
                    if (kbState.IsKeyDown(Keys.S))
                    {
                        player.PlayerState = PlayerState.FacingDown;
                    }
                    if (kbState.IsKeyDown(Keys.D))
                    {
                        player.PlayerState = PlayerState.WalkingRight;
                    }
                    if (kbState.IsKeyDown(Keys.W))
                    {
                        player.PlayerState = PlayerState.FacingUp;
                    }
                    if (kbState.IsKeyDown(Keys.A))
                    {
                        player.PlayerState = PlayerState.FacingLeft;
                    }
                    break;
                }
                case PlayerState.FacingUp:{
                    if (kbState.IsKeyDown(Keys.S))
                    {
                        player.PlayerState = PlayerState.FacingDown;
                    }
                    if (kbState.IsKeyDown(Keys.D))
                    {
                        player.PlayerState = PlayerState.FacingRight;
                    }
                    if (kbState.IsKeyDown(Keys.W))
                    {
                        player.PlayerState = PlayerState.WalkingUp;
                    }
                    if (kbState.IsKeyDown(Keys.A))
                    {
                        player.PlayerState = PlayerState.FacingLeft;
                    }
                    break;
                }
                case PlayerState.WalkingDown:{
                    if(kbState.IsKeyUp(Keys.S)){
                        player.PlayerState = PlayerState.FacingDown;
                    }
                    break;
                }
                case PlayerState.WalkingLeft:{
                    if(kbState.IsKeyUp(Keys.A)){
                        player.PlayerState = PlayerState.FacingLeft;
                    }
                    break;
                }
                case PlayerState.WalkingRight:{
                    if(kbState.IsKeyUp(Keys.D)){
                        player.PlayerState = PlayerState.FacingRight;
                    }
                    break;
                }
                case PlayerState.WalkingUp:{
                    if(kbState.IsKeyUp(Keys.W)){
                        player.PlayerState = PlayerState.FacingUp;
                    }
                    break;
                }
            }
        }

        public void ProcessMovement()
        {
            //Updates the players position based on the players state.
            if(player.PlayerState == PlayerState.WalkingDown){
                player.Y += player.Speed;
                if(kbState.IsKeyDown(Keys.A)){
                    player.X -= player.Speed;
                }
                else if(kbState.IsKeyDown(Keys.D)){
                    player.X += player.Speed;
                }
            }
            if(player.PlayerState == PlayerState.WalkingLeft){
                player.X -= player.Speed;
                if(kbState.IsKeyDown(Keys.W)){
                    player.Y -= player.Speed;
                }
                else if(kbState.IsKeyDown(Keys.S)){
                    player.Y += player.Speed;
                }
            }
            if(player.PlayerState == PlayerState.WalkingRight){
                player.X += player.Speed;
                if(kbState.IsKeyDown(Keys.W)){
                    player.Y -= player.Speed;
                }
                else if(kbState.IsKeyDown(Keys.S)){
                    player.Y += player.Speed;
                }
            }
            if(player.PlayerState == PlayerState.WalkingUp){
                player.Y -= player.Speed;
                if(kbState.IsKeyDown(Keys.A)){
                    player.X -= player.Speed;
                }
                else if(kbState.IsKeyDown(Keys.D)){
                    player.X += player.Speed;
                }
            }       
        }

        public void ProcessPickup()
        {
            if(KeyPress(Keys.F))
            {
                if(player.HeldItem == null)
                {
                    //Attempts to pickup the item in front of the player. If successful, removes it from the level.
                    if (player.PickUp(levelManager.ThisLevel.InteractableAt(player.TargetPosition)))
                    {
                        levelManager.ThisLevel.RemoveInteractable(player.HeldItem);
                    }
                } else
                {
                    player.PutDown(levelManager.ThisLevel);
                }
                
            }
        }

        public void ProcessTimeTravel()
        {
            if(KeyPress(Keys.Space))
            {
                // A list of all interactables that would collide in the future.
                List<Interactable> collidingInteractables = levelManager.ThisLevel.InteractablesCollidingInOtherTime();

                if (collidingInteractables.Count == 0 & !colManager.PlayerIsCollidingInOtherTime())
                {
                    animManager.StartTimeTravel();
                } else
                {
                    foreach (Interactable i in collidingInteractables)
                    {
                        levelManager.ThisLevel.Indicators.Add(new Indicator(i, Color.Red, 1));
                    }
                    if(colManager.PlayerIsCollidingInOtherTime())
                    {
                        levelManager.ThisLevel.Indicators.Add(new Indicator(player, Color.Red, 1));
                    }
                }
                
            }
        }

        public void ProcessUIElements()
        {
            //Finite State Machine to check necessary input for each state.
            switch (Game1.gameState)
            {
                case GameState.Start:
                    {
                        //Start button is clicked.
                        if (uiManager["start"].Clicked())
                        {
                            Game1.gameState = GameState.Level1;
                        }
                        break;
                    }
                case GameState.PauseMenu:
                    {
                        //Resume button is clicked.
                        if (uiManager["resume"].Clicked())
                        {
                            //Level 1.
                            if (levelManager.CurrentLevel == 0)
                            {
                                Game1.gameState = GameState.Level1;
                            }
                            //Level 2.
                            else if (levelManager.CurrentLevel == 1)
                            {
                                Game1.gameState = GameState.Level2;
                            }
                            //Level 3.
                            else if (levelManager.CurrentLevel == 1)
                            {
                                Game1.gameState = GameState.Level3;
                            }
                        }
                        break;
                    }
                case GameState.End:
                    {
                        break;
                    }
                //Otherwise, the player is in a level.
                default:
                    {
                        //Pause button is clicked.
                        if (uiManager["pause"].Clicked())
                        {
                            Game1.gameState = GameState.PauseMenu;
                        }
                        break;
                    }
            }
        }
    }
}
