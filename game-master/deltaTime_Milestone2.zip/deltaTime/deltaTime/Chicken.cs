﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace deltaTime
{
    /// <summary>
    /// enum for the different possible states of Chicken
    /// </summary>
    public enum ChickenState { PastNothing, Egg, Chick, Chicken, Bones, FutureNothing }

    /// <summary>
    /// class that stores data about the chicken 
    /// </summary>
    class Chicken : Interactable
    {
        private ChickenState state;
        private Dictionary<ChickenState, AnimatedTexture> textures;

        /// <summary>
        /// Gets the state of the chicken
        /// </summary>
        public ChickenState State
        {
            get
            {
                return state;
            }
        }

        /// <summary>
        /// indexer property for textures. Includes a getter and setter.
        /// </summary>
        /// <param name="c">The state the chicken is in</param>
        /// <returns>The AnimatedTexture for that state of the chicken</returns>
        public AnimatedTexture this[ChickenState s]
        {
            get
            {
                return textures[s];
            }
        }

        /// <summary>
        /// Creates a chicken at given position and at given state. Collidable by default, (if we find a need for uncollidable chickens we'll need an extra parameter here).
        /// </summary>
        /// <param name="position">The starting position of the Chicken.</param>
        /// <param name="state"></param>
        public Chicken(Rectangle position, ChickenState state, double scale):base(position, true, scale)
        {
            this.state = state;
            textures = new Dictionary<ChickenState, AnimatedTexture>();
        }

        /// <summary>
        /// Updates the chickens finite state machine.
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Update(GameTime gameTime)
        {
            //implement code here
        }

        /// <summary>
        /// draws the chicken at its position and current state.
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Draw(GameTime gameTime, SpriteBatch sb)
        {
            textures[state].Draw(Position, sb, gameTime, SpriteEffects.None);
        }

        /// <summary>
        /// changes the current state of the chicken to its previous state as long as it isn't in its base state
        /// </summary>
        public override void GoToPast()
        {
            switch (state)
            {
                case ChickenState.PastNothing: //this should never happen
                    break;
                case ChickenState.Egg:
                    state = ChickenState.PastNothing;
                    Collidable = false;
                    break;
                case ChickenState.Chick:
                    state = ChickenState.Egg;
                    Collidable = true;
                    break;
                case ChickenState.Chicken:
                    state = ChickenState.Chick;
                    Collidable = true;
                    break;
                case ChickenState.Bones:
                    state = ChickenState.Chicken;
                    Collidable = true;
                    break;
                case ChickenState.FutureNothing:
                    state = ChickenState.Bones;
                    Collidable = true;
                    break;
            }
        }

        /// <summary>
        /// changes the current state of the chicken to its next state as long as it isn't in its oldest state.
        /// </summary>
        public override void GoToFuture()
        {
            switch (state)
            {
                case ChickenState.PastNothing:
                    state = ChickenState.Egg;
                    Collidable = true;
                    break;
                case ChickenState.Egg:
                    state = ChickenState.Chick;
                    Collidable = true;
                    break;
                case ChickenState.Chick:
                    state = ChickenState.Chicken;
                    Collidable = true;
                    break;
                case ChickenState.Chicken:
                    state = ChickenState.Bones;
                    Collidable = true;
                    break;
                case ChickenState.Bones:
                    state = ChickenState.FutureNothing;
                    Collidable = false;
                    break;
                case ChickenState.FutureNothing: //this should never happen
                    break;
            }
        }

        /// <summary>
        /// Loads a dictionary mapping ChickenStates to SpriteSheets, 
        /// converts it to a dictionary mapping ChickenStates to 
        /// AnimatedTextures, then sets this Chicken's texture field
        /// to that dictionary
        /// </summary>
        /// <param name="spriteSheets">The dictionary</param>
        /// <param name="fps">The fps of the animatedTextures</param>
        /// <param name="widthOfFrame">The width of frame of the animatedTextures</param>
        /// <param name="heightOfFrame">The height of frame of the animatedTextures</param>
        public override void LoadTextures(IDictionary spriteSheets)
        {
            //converts to chicken-specific spritesheets
            Dictionary<ChickenState, Texture2D> castedSpriteSheets = (Dictionary<ChickenState, Texture2D>)spriteSheets;

            //converts to animatedTextures
            //int values of fps, width, and height can be changed here and should probably be kept as variables somewhere
            Dictionary<ChickenState, AnimatedTexture> animatedTextures = ConvertTextures(castedSpriteSheets, 2, 16, 16);

            textures = animatedTextures;
        }
    }
}
